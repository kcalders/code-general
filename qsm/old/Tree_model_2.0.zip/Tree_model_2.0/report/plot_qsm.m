
load('results/data.mat')

plot_cylinder_model(Rad,Len,Axe,Sta,1,20,0.3)
pause(0.01)