
display_info
plot_qsm

%% Basic tree attributes
display_attributes

%% Trunk taper and cumulative volume
display_taper

%% Cumulative volume and length by branch order
display_cum_order

%% Cumulative volume and length by size
display_cum_size

%% Branch volume distributions
display_volumes

%% Branch length distributions
display_lengths

%% Branch frequency distributions
display_frequency

