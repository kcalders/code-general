
load('results/data3_Tree5_H.mat')

disp(['Tree: ' strT])
disp(datestr(clock))
disp(['Number of models: ',num2str(N*length(dmin1)*4)])
disp('-------')
pause(0.01)
